/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "ssd1306.h"
#include "ssd1306_tests.h"
I2C_HandleTypeDef hi2c1;
/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_I2C1_Init(void);


/**
  * @brief  The application entry point.
  * @retval int
  */
//  /******************************************************************************
//  * @file           : main.c
//  * @brief          : Main program body
//  * (c) WANG BOYU 		A0271919U
//  *     WILLIAM GU EN YAO A0276989W
//  ******************************************************************************/
//
//
#include "main.h"
#include "stdio.h"
#include "string.h"
#include <stdlib.h>
#include "../../Drivers/BSP/B-L475E-IOT01/stm32l475e_iot01.h"
#include "../../Drivers/BSP/B-L475E-IOT01/stm32l475e_iot01_magneto.h"
#include "../../Drivers/BSP/B-L475E-IOT01/stm32l475e_iot01_tsensor.h"
#include "../../Drivers/BSP/B-L475E-IOT01/stm32l475e_iot01_hsensor.h"
#include "../../Drivers/BSP/B-L475E-IOT01/stm32l475e_iot01_psensor.h"
#include "../../Drivers/BSP/B-L475E-IOT01/stm32l475e_iot01_accelero.h"
#include "../../Drivers/BSP/B-L475E-IOT01/stm32l475e_iot01_gyro.h"
#include <math.h> // For sqrt function that calculates combined values for Accelero/Magneto/Gyro readings

#define GYRO_SCALE_FACTOR_2000 (2000.0f / 32768.0f) // Correct scale factor for ±2000 dps
#define temperature_threshold 10 //Sudden drop of 10 degrees C means ghost around
#define pressure_threshold  20.59//Sudden increase in pressure means ghost around
#define humidity_threshold  20//Sudden drop in humidity level of 20 percent means ghost around
#define magnetometer_threshold 4000//Magneto reading over 4000 indicates Ghost is within capture range
#define magnetometer_threshold_min 200//Magneto reading over 100 indicates Ghost is detectable
#define accelerometer_threshold 2 //if a sudden acceleration over 2 m/s^2, indicates it is unusual
#define gyro_threshold 6000 //if a sudden combined gyro change exceeds 6000 compared to normal reading, indicates it is unusual, might be ghost around
static void MX_GPIO_Init_PB(void);//////Configure GPIO Pin for Button///////
static void UART1_Init(void);//Configure UART for transmission
extern void initialise_monitor_handles(void);
UART_HandleTypeDef huart1;
float* Get_Accelerometer_Values(void);//Retrieve Accelerometer readings  in x,y,z
float* Get_Gyro_Values(void);//Retrieve Gyroscope readings in x,y,z
void Button_Dectection(void);//Detect single press and double press
float Get_Magneto_Magnitude(void);//Retrieve Magnetometer combined readings
void average_temp_update(float);//To update each temperature reading to obtain average temperature readings
void average_pressure_update(float);//To update each pressure reading to obtain average pressure readings
void average_humidity_update(float);//To update each humidity reading to obtain average humidity readings
void average_magneto_update(float);////To update each Magetometer reading to obtain average Magnetometer readings
void average_accelero_update(float);//To update each accelerometer reading to obtain average accelerometer readings
void average_gyro_update(float);////To update each gyro reading to obtain average gyro readings
volatile int button_count = 0; // Count number of presses
volatile uint32_t lastPressTime = 0; // Use uint32_t variable for last time button toggled tracking
volatile int single_press = 0; //indicates if single press detected
volatile int double_press = 0; //indicates if double press detected
volatile int curr_mode = 0; 	//0 is Normal Mode, 1 is Ghost Busting Mode
volatile int message_print_status = 0; //0 means Normal/Ghost Busting mode message has not been printed
volatile float average_temp = 0;//Stores average temperature readings
volatile int temp_unusual = 0;//0 means temperature no sudden change, 1 means unusual change
volatile float average_pressure = 0;
volatile int pressure_unusual = 0;//0 means pressure no sudden change, 1 means unusual change
volatile float average_humidity = 0;
volatile int humidity_unusual = 0;//0 means humidity no sudden change, 1 means unusual change
volatile float average_magneto;
volatile float average_magneto_ary[3];//Stores average magneto readings in array of size 3 for x,y,z
volatile int magneto_unusual = 0;//0 means magnetometer has not reached threshold, 1 means threshold reached
volatile int Calibration = 0;//0 means Calibration not ready, 1 means Calibration is ready and 2 means done
volatile float average_accelerometer = 0;
volatile float average_accelerometer_ary[3];//Stores average accelerometer readings in array of size 3 for x,y,z
volatile int accelerometer_unusual = 0;//0 means accelerometer no sudden change, 1 means unusual change
volatile int Calibration_accelerometer = 0;//0 means Calibration has not been done, 1 means Calibration is ready and 2 means done
volatile float average_gyro = 0;
volatile float average_gyro_ary[3];
volatile int gyro_unusual = 0;//0 means gyro no sudden change, 1 means unusual change
volatile int Calibration_gyro = 0;//0 means Calibration has not been done, 1 means Calibration is ready and 2 means done
volatile int No_Ghost_Captured = 0;//stores the number of ghost captured in a run
volatile int Ghost_Capture_status = 0;//0 indicates the ghost is not available to be captured yet, 1 indicates ready to capture, 2 means captured
//OLED
static void MX_I2C1_Init(void);
I2C_HandleTypeDef hi2c1;
#include "ssd1306.h"
#include "ssd1306_tests.h"
//Buzzer
static void BUZZ_GPIO_Init(void);
void BUZZER_On(void);
void BUZZER_Off(void);
void BUZZER_Toggle(void);
//Button interrupt
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if(GPIO_Pin == BUTTON_EXTI13_Pin) // Check if the interrupt is from the button
    {
        uint32_t current_time = HAL_GetTick(); // Get current time in milliseconds

        if (button_count == 0) {
            lastPressTime = current_time; // Record time of first press
            button_count = 1; // First press detected

        } else if (button_count == 1) {
            button_count = 0; // reset
            double_press = 1; // Mark double press detected
        }

    }
}

int main(void)
{
    /* Reset of all peripherals, Initializes Systick etc. */
    HAL_Init();
    BUZZ_GPIO_Init();
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init_PB();
	MX_I2C1_Init();
	/* USER CODE BEGIN 2 */
	ssd1306_Init();
	//OLED
	MX_I2C1_Init();
	ssd1306_Init();
	//
	BSP_LED_Init(LED2);
//    initialise_monitor_handles();

    /* UART initialization  */
    UART1_Init();
    /* Sensors initialization */
    BSP_TSENSOR_Init();
    BSP_PSENSOR_Init();
    BSP_HSENSOR_Init();
    BSP_ACCELERO_Init();
    BSP_GYRO_Init();
    BSP_MAGNETO_Init();
	uint32_t current_time = HAL_GetTick();
	uint32_t start_time1 = HAL_GetTick();
	int no_sec_cali = 0;

    while (1)
    {
    	//Normal mode
        if (curr_mode == 0){
        	BUZZER_Off();
        	BSP_LED_Off(LED2);
        	if (message_print_status == 0){
        		if (No_Ghost_Captured != 0){
        			char message_print[35];
       				sprintf(message_print, "Total ghosts captured: [%.d]\r\n", No_Ghost_Captured);
 					HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print), 0xFFFF);
 				//Reset the number of ghost captured
 					No_Ghost_Captured = 0;
        		}
				char message_temp[] = "Entering Normal_Mode...";
				char message_print[26]; //Normal mode welcome message, less than size 26
				sprintf(message_print, "%s\r\n", message_temp);
				HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print), 0xFFFF);
				message_print_status = 1;
        	}

        	if (HAL_GetTick() - current_time > 1000){
				//declare and measure all readings from the 6 sensors every second//
        		float temp;
				float pressure;
				float humidity;
				float* accelero = Get_Accelerometer_Values();
		        float accelero_combined = sqrt(accelero[0] * accelero[0] +
		        							accelero[1] * accelero[1] +
											accelero[2] * accelero[2]);
				float* gyro_values = Get_Gyro_Values();
				float gyro_combined = sqrt(gyro_values[0] * gyro_values[0] +
											gyro_values[1] * gyro_values[1] +
											gyro_values[2] * gyro_values[2]);
				float magneto_magnitude = Get_Magneto_Magnitude();
				temp = BSP_TSENSOR_ReadTemp();
				pressure = BSP_PSENSOR_ReadPressure();
				humidity = BSP_HSENSOR_ReadHumidity();
				average_temp_update(temp);
				average_pressure_update(pressure);
				average_humidity_update(humidity);
				average_accelero_update(accelero_combined);
				if (Calibration == 0 && Calibration_accelerometer == 0 && Calibration_gyro == 0){
					average_magneto_update(magneto_magnitude);
					average_accelero_update(accelero_combined);
					average_gyro_update(gyro_combined);
					no_sec_cali++;
				}
				if (no_sec_cali == 3 && Calibration == 0 && Calibration_accelerometer == 0 && Calibration_gyro == 0){
					Calibration = 1;
					Calibration_accelerometer = 1;
					Calibration_gyro = 1;
				}
				//format the readings to transmit to Tera Term via UART
				char reading_print[150];
				//Temperature:Degree Celsius|Pressure:hectoPascals|Humidity:Percent|Accelerometer:meter per sec square|Gyro:degrees per sec|Megnetometer:microTesla
				sprintf(reading_print, "T:%.2f Degree Celsius, P:%.2f hPa, H:%.2f %%, A:x:%.2f;y:%.2f;z:%.2f m/s^2, G:x:%.2f;y:%.2f;z:%.2f degrees/sec, M:%.2f microT\r\n", temp, pressure, humidity, accelero[0], accelero[1],accelero[2], gyro_values[0], gyro_values[1], gyro_values[2], magneto_magnitude);
				HAL_UART_Transmit(&huart1, (uint8_t*)reading_print, strlen(reading_print), 0xFFFF);
				current_time = HAL_GetTick();

			}
        	Button_Dectection();
        	//Ghost Busting Mode
        } else if (curr_mode == 1 && Ghost_Capture_status != 2){

        	if (message_print_status == 0){
				char message_temp[] = "Entering Ghost_Busting_Mode...";
				char message_print[33]; //Ghost Busting Mode mode welcome message, less than size 33
				sprintf(message_print, "%s\r\n", message_temp);
				HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print), 0xFFFF);
				message_print_status = 1;
        	}
        	float magneto_magnitude = Get_Magneto_Magnitude();
			//LED blink at 2 Hz when no ghost around
        	if (HAL_GetTick() - start_time1 >= 500 && magneto_magnitude < magnetometer_threshold_min){
				start_time1 = HAL_GetTick();
				BSP_LED_Toggle(LED2);
				BUZZER_Off();
				//LED blinks smoothly according to magneto_magnitude strength
				//*Ghost is detected but not in range to burst
			} else if (magneto_magnitude < magnetometer_threshold && magneto_magnitude > magnetometer_threshold_min){
				ssd1306_GhostArd();
				float blink_period = (4000 / magneto_magnitude) * 50;
				if (HAL_GetTick() - start_time1 >= blink_period){
					start_time1 = HAL_GetTick();
					BSP_LED_Toggle(LED2);
					BUZZER_Toggle();
				}
				//*Ghost is within capture range (4000)
			} else if (magneto_magnitude >= magnetometer_threshold && Ghost_Capture_status !=2){
				BUZZER_On();
				Ghost_Capture_status = 1;//Update flag to notify program that ready to capture
				float blink_period = 50;
				if (HAL_GetTick() - start_time1 >= blink_period){
					start_time1 = HAL_GetTick();
					BSP_LED_Toggle(LED2);
				}
				//magnetic field strength exceeds the threshold, a warning message is sent via UART
				if (HAL_GetTick() - current_time > 1000){
					char message_temp[] = "Ghost detected in! Prepare to bust!";
					char message_print[40];
					sprintf(message_print, "%s\r\n", message_temp);
					HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print), 0xFFFF);
				}

				if (magneto_magnitude < magnetometer_threshold){
					Ghost_Capture_status = 0;
				}
				Button_Dectection();

			} else {
				ssd1306_GhostSearch();
			}

			if (Ghost_Capture_status == 2){
				BUZZER_Off();
				ssd1306_Explode();
				BSP_LED_Off(LED2);
				No_Ghost_Captured++;
				char message_temp[] = "Ghost Captured!";
				char message_print[20];
				sprintf(message_print, "%s\r\n", message_temp);
				HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print), 0xFFFF);
			}


			//declare and measure all readings from the 6 sensors//
			if (HAL_GetTick() - current_time > 1000){
				float temp;
				float pressure;
				float humidity;
				float* accelero = Get_Accelerometer_Values();
		        float accelero_combined = sqrt(accelero[0] * accelero[0] +
		        							accelero[1] * accelero[1] +
											accelero[2] * accelero[2]);
				float* gyro_values = Get_Gyro_Values();
				float gyro_combined = sqrt(gyro_values[0] * gyro_values[0] +
											gyro_values[1] * gyro_values[1] +
											gyro_values[2] * gyro_values[2]);

				temp = BSP_TSENSOR_ReadTemp();
				pressure = BSP_PSENSOR_ReadPressure();
				humidity = BSP_HSENSOR_ReadHumidity();
				average_temp_update(temp);
				average_pressure_update(pressure);
				average_humidity_update(humidity);
				average_accelero_update(accelero_combined);
				average_gyro_update(gyro_combined);
				//Check if detection of threshold violations in gyro occurs
				if (gyro_unusual == 1){
					char message_print[100];
					sprintf(message_print, "Device orientation compromised! Latest reading: unusual Gyroscope: %.2f degrees per sec\r\n", gyro_combined);
					HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print), 0xFFFF);
				}
				//Check if detection of threshold violations in accelerometer occurs
				if (accelerometer_unusual == 1){
					char message_print[100];
					sprintf(message_print, "Device orientation compromised! Latest reading: unusual Acceleration: %.2f m/s^2\r\n", accelero_combined);
					HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print), 0xFFFF);
				}
				//Check if detection of threshold violations in temperature occurs
				if (temp_unusual == 1){
					char message_print[100];
					sprintf(message_print, "Sudden temperature drop detected! Latest reading: %.2f Degree Celsius. Possible ghost nearby!\r\n", temp);
					HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print), 0xFFFF);
				}
				//Check if detection of threshold violations in pressure occurs
				if (pressure_unusual == 1){
					char message_print[90];
					sprintf(message_print, "Pressure anomaly detected! Latest reading: %.2f hPa. Ghost activity suspected.\r\n", pressure);
					HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print), 0xFFFF);
				}
				//Check if detection of threshold violations in humidity occurs
				if (humidity_unusual == 1){
					char message_print[90];
					sprintf(message_print, "Atmospheric change detected! Latest reading: %.2f %%. Possible ghostly presence!\r\n", humidity);
					HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print), 0xFFFF);
				}
				current_time = HAL_GetTick();

			}
			Button_Dectection();
        }
        Button_Dectection();
    }
}
//Function to take note of gyro values and update gyro_average
void average_gyro_update(float curr_gyro){
	if (average_gyro == 0){
		average_gyro = curr_gyro;
	} else {
		if (curr_gyro - average_gyro  >= gyro_threshold){
			gyro_unusual = 1;
		} else {
			average_gyro = (average_gyro + curr_gyro) / 2;
			gyro_unusual = 0;
		}
	}
}
//Function to take note of accelerometer values and update average_accelerometer
void average_accelero_update(float curr_accelero){
	if (average_accelerometer == 0){
		average_accelerometer = curr_accelero;
	} else {
		if (curr_accelero - average_accelerometer  >= accelerometer_threshold){
			accelerometer_unusual = 1;
		} else {
			average_accelerometer = (average_accelerometer + curr_accelero) / 2;
			accelerometer_unusual = 0;
		}
	}
}
//Function to take note of megnetometer values and update average_magneto
void average_magneto_update(float curr_magneto){
	if (average_magneto == 0){
		average_magneto = curr_magneto;
	} else {
		if (average_magneto - curr_magneto >= magnetometer_threshold){
			magneto_unusual = 1;
		} else {
			average_magneto = (average_magneto + curr_magneto) / 2;
		magneto_unusual = 0;
		}
	}
}
//Function to take note of humidity values and update humidity
void average_humidity_update(float curr_humidity){
	if (average_humidity == 0){
		average_humidity = curr_humidity;
	} else {
		if (average_humidity - curr_humidity >= humidity_threshold){
			humidity_unusual = 1;
		} else {
			average_humidity = (average_humidity + curr_humidity) / 2;
		humidity_unusual = 0;
		}
	}
}
//Function to take note of temperature values and update average_temp
void average_temp_update(float curr_temp){
	if (average_temp == 0){
		average_temp = curr_temp;
	} else {
		if (average_temp - curr_temp >= temperature_threshold){
			temp_unusual = 1;
		} else {
		average_temp = (average_temp + curr_temp) / 2;
		temp_unusual = 0;
		}
	}
}
//Function to take note of pressure values and update average_pressure
void average_pressure_update(float curr_pressure){
	if (average_pressure == 0){
		average_pressure = curr_pressure;
	} else {
		if (curr_pressure - average_pressure >= pressure_threshold){
			pressure_unusual = 1;
		} else {
		average_pressure = (average_pressure + curr_pressure) / 2;
		pressure_unusual = 0;
		}
	}
}
// Function to get Magnetometer overall magnitude
float Get_Magneto_Magnitude(void) {
    int16_t mag_data_i16[3] = { 0 }; // Array to store the raw x, y, z readings
    float mag_data[3]; // Array to hold X, Y, Z values

    // Read magnetometer values
    BSP_MAGNETO_GetXYZ(mag_data_i16); // Replace with your actual function to read magnetometer data

    // Convert raw readings to float
    mag_data[0] = (float)mag_data_i16[0]; // Assuming raw values are in microteslas (µT)
    mag_data[1] = (float)mag_data_i16[1];
    mag_data[2] = (float)mag_data_i16[2];

    if (Calibration == 1 | Calibration == 2){
    	if (Calibration == 1){
			char message_print[100];
			sprintf(message_print, "Calibration for magnetometer done!\r\nBefore:x-%.2f;y-%.2f;z-%.2f microT\r\n", mag_data[0], mag_data[1], mag_data[2]);
			HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print), 0xFFFF);
    	}
    	mag_data[0] = mag_data[0] - average_magneto_ary[0];
    	mag_data[1] = mag_data[1] - average_magneto_ary[1];
    	mag_data[2] = mag_data[2] - average_magneto_ary[2];
    	if (Calibration == 1){
			char message_print_after[100];
			sprintf(message_print_after, "After:x-%.2f;y-%.2f;z-%.2f microT\r\n\n", mag_data[0], mag_data[1], mag_data[2]);
			HAL_UART_Transmit(&huart1, (uint8_t*)message_print_after, strlen(message_print_after), 0xFFFF);
			Calibration = 2;
    	}
        // Calculate the magnitude of the magnetic field vector
        float magnitude = sqrt(mag_data[0] * mag_data[0] +
                               mag_data[1] * mag_data[1] +
                               mag_data[2] * mag_data[2]);
    	return magnitude;
    } else if (Calibration == 0){
    	average_magneto_ary[0] = (float)mag_data_i16[0];
    	average_magneto_ary[1] = (float)mag_data_i16[1];
    	average_magneto_ary[2] = (float)mag_data_i16[2];
    }
    // Calculate the magnitude of the magnetic field vector
    float magnitude = sqrt(mag_data[0] * mag_data[0] +
                           mag_data[1] * mag_data[1] +
                           mag_data[2] * mag_data[2]);


    return magnitude; // Return the calculated magnitude
}
// Function to get Gyroscope values
float* Get_Gyro_Values(void) {
    static float gyro_data[3]; // Array to hold X, Y, Z values
    float gyro_data_i16[3] = { 0 }; // Array to store the raw x, y, z readings

    // Read gyroscope values
    BSP_GYRO_GetXYZ(gyro_data_i16); // Replace with your actual function to read gyro data
    float scale_factor;
    scale_factor = GYRO_SCALE_FACTOR_2000;
    // Convert raw readings to degrees per second using the determined scale factor
    gyro_data[0] = (float)gyro_data_i16[0] * scale_factor;
    gyro_data[1] = (float)gyro_data_i16[1] * scale_factor;
    gyro_data[2] = (float)gyro_data_i16[2] * scale_factor;
    if (Calibration_gyro == 1 | Calibration_gyro == 2){
    	    	if (Calibration_gyro == 1){
    				char message_print[100];
    				sprintf(message_print, "Calibration for Gyroscope done!\r\nBefore:x-%.2f;y-%.2f;z-%.2f degrees per sec\r\n", gyro_data[0], gyro_data[1], gyro_data[2]);
    				HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print), 0xFFFF);
    	    	}
    	    	gyro_data[0] = gyro_data[0] - average_gyro_ary[0];
    	    	gyro_data[1] = gyro_data[1] - average_gyro_ary[1];
    	    	gyro_data[2] = gyro_data[2] - average_gyro_ary[2];
    	    	if (Calibration_gyro == 1){
    				char message_print_after[100];
    				sprintf(message_print_after, "After:x-%.2f;y-%.2f;z-%.2f degrees per sec\r\n\n", gyro_data[0], gyro_data[1], gyro_data[2]);
    				HAL_UART_Transmit(&huart1, (uint8_t*)message_print_after, strlen(message_print_after), 0xFFFF);
    				Calibration_gyro = 2;
    	    	}
    	    	return gyro_data;
    	    } else if (Calibration_gyro == 0){
    	    	average_gyro_ary[0] = (float)gyro_data_i16[0] * scale_factor;
    	    	average_gyro_ary[1] = (float)gyro_data_i16[1] * scale_factor;
    	    	average_gyro_ary[2] = (float)gyro_data_i16[2] * scale_factor;
    	    }

    return gyro_data; // Return pointer to the array
}
///////Function to get Accelerometer values/////
float* Get_Accelerometer_Values(void) {
    static float accel_data[3]; // Array to hold X, Y, Z values
	int16_t accel_data_i16[3] = { 0 };			// array to store the x, y and z readings.
	BSP_ACCELERO_AccGetXYZ(accel_data_i16);		// read accelerometer
	// the function above returns 16 bit integers which are acceleration in mg (9.8/1000 m/s^2).
	// Converting to float to print the actual acceleration.
	accel_data[0] = (float)accel_data_i16[0] * (9.8/1000.0f);
	accel_data[1] = (float)accel_data_i16[1] * (9.8/1000.0f);
	accel_data[2] = (float)accel_data_i16[2] * (9.8/1000.0f);
	if (Calibration_accelerometer == 1 | Calibration_accelerometer == 2){
	    	if (Calibration_accelerometer == 1){
				char message_print[100];
				sprintf(message_print, "Calibration for accelerometer done!\r\nBefore:x-%.2f;y-%.2f;z-%.2f m/s^2\r\n", accel_data[0], accel_data[1], accel_data[2]);
				HAL_UART_Transmit(&huart1, (uint8_t*)message_print, strlen(message_print), 0xFFFF);
	    	}
	    	accel_data[0] = accel_data[0] - average_accelerometer_ary[0];
	    	accel_data[1] = accel_data[1] - average_accelerometer_ary[1];
	    	accel_data[2] = accel_data[2] - average_accelerometer_ary[2];
	    	if (Calibration_accelerometer == 1){
				char message_print_after[100];
				sprintf(message_print_after, "After:x-%.2f;y-%.2f;z-%.2f m/s^2\r\n\n", accel_data[0], accel_data[1], accel_data[2]);
				HAL_UART_Transmit(&huart1, (uint8_t*)message_print_after, strlen(message_print_after), 0xFFFF);
				Calibration_accelerometer = 2;
	    	}
	    	return accel_data;
	    } else if (Calibration_accelerometer == 0){
	    	average_accelerometer_ary[0] = (float)accel_data_i16[0] * (9.8/1000.0f);
	    	average_accelerometer_ary[1] = (float)accel_data_i16[1] * (9.8/1000.0f);
	    	average_accelerometer_ary[2] = (float)accel_data_i16[2] * (9.8/1000.0f);
	    }
    return accel_data; // Return pointer to the array
}
///////Function to detect button pressed status////////
void Button_Dectection(void){
	uint32_t current_time = HAL_GetTick(); // Get current time in milliseconds
	// Check for single press confirmation after waiting for another second

	if (button_count == 1){
		if (current_time - lastPressTime >= 1000){
			single_press = 1;
			button_count = 0;
		}
	}

	if (single_press == 1){
		//Check if ghost is ready to be captured
        if (Ghost_Capture_status == 1){
			//Update flag to notify that ghost is captured
			Ghost_Capture_status = 2;
			//Go back to normal detection mode with 1 press after a ghost captured
		} else if (Ghost_Capture_status == 2){
			Ghost_Capture_status = 0;
		}

		single_press = 0;
		double_press = 0;
		button_count = 0;
		lastPressTime = current_time;
	}

	if (double_press == 1 && Ghost_Capture_status != 2){
		if (curr_mode == 0){
			curr_mode = 1;
		} else {
			curr_mode = 0;
		}
		double_press = 0;
		single_press = 0;
		button_count = 0;
		message_print_status = 0;
		lastPressTime = current_time;

	}



}
//I2C

//////Configure GPIN Pin for Button///////
static void MX_GPIO_Init_PB(void)
{
    __HAL_RCC_GPIOC_CLK_ENABLE();	// Enable AHB2 Bus for GPIOC

    GPIO_InitTypeDef GPIO_InitStruct = {0};

    // Configuration of BUTTON_EXTI13_Pin (GPIO-C Pin-13) as AF,
    GPIO_InitStruct.Pin = BUTTON_EXTI13_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING; // Trigger on falling edge
    GPIO_InitStruct.Pull = GPIO_NOPULL; // No pull-up or pull-down resistors
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    // Enable NVIC EXTI line 13
    HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
}
///////////////UART Init//////////////////////
static void UART1_Init(void)
{
        /* Pin configuration for UART. BSP_COM_Init() can do this automatically */
        __HAL_RCC_GPIOB_CLK_ENABLE();
        GPIO_InitTypeDef GPIO_InitStruct = {0};
        GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
        GPIO_InitStruct.Pin = GPIO_PIN_7|GPIO_PIN_6;
        GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Pull = GPIO_NOPULL;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
        HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

        /* Configuring UART1 */
        huart1.Instance = USART1;
        huart1.Init.BaudRate = 115200;
        huart1.Init.WordLength = UART_WORDLENGTH_8B;
        huart1.Init.StopBits = UART_STOPBITS_1;
        huart1.Init.Parity = UART_PARITY_NONE;
        huart1.Init.Mode = UART_MODE_TX_RX;
        huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
        huart1.Init.OverSampling = UART_OVERSAMPLING_16;
        huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
        huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
        if (HAL_UART_Init(&huart1) != HAL_OK)
        {
          while(1);
        }
}



/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();
  __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSE|RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 40;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }

  /** Enable MSI Auto calibration
  */
  HAL_RCCEx_EnableMSIPLLMode();
}



/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x00F12981;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}



void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
static void BUZZ_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, ARD_A4_Pin, GPIO_PIN_RESET);

  GPIO_InitStruct.Pin = ARD_A4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

void BUZZER_On(void)
{
    HAL_GPIO_WritePin(GPIOB, ARD_A4_Pin, GPIO_PIN_SET); // Set the pin high to turn on the buzzer
}

void BUZZER_Off(void)
{
    HAL_GPIO_WritePin(GPIOB, ARD_A4_Pin, GPIO_PIN_RESET); // Set the pin low to turn off the buzzer
}

void BUZZER_Toggle(void)
{
    HAL_GPIO_TogglePin(GPIOB, ARD_A4_Pin); // Toggle the pin to turn on and off the buzzer
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
